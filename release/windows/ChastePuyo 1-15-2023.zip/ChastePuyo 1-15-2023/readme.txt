This folder has the source code written in C using Raylib. None of the compilation has changed since copying the files from Chaste Tris.

Since this is a clone of Chaste Tris, all controls are the same. Most notably rotation is done with Z and X.
Arrow keys or WASD for movement.

Oddly enough, the hold feature from Tetris is also still available from Chaste Tris by pressing C. This violates Puyo Puyo rules but there is nothing to stop you from it.

Saving and loading with . and , is also still allowed. This means building up extreme chains is possible because mistakes can be fixed.
